using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextBehavior : MonoBehaviour
{
    private Text thisText;
    private static string data;
    private static bool changed;

    void Start()
    {
        changed = false;
        thisText = GetComponent<Text>();
    }

    void Update()
    {
        if (changed)
        {
            thisText.text = "Received Data: " + data;
            changed = false;
        }
        
    }

    public static void AddNewData(string d)
    {
        data = d;
        changed = true;
    }
}
