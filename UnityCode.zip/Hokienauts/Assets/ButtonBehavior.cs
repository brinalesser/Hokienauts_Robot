using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO.Ports;
using System.Text;


public class ButtonBehavior : MonoBehaviour
{
    // Start is called before the first frame update

    public Text status;
    private SerialPort port;

    public void ButtonPressHandler()
    {
        if (port == null)
        {
            status.text = "Connecting...";
            try
            {
                port = new SerialPort();
                port.BaudRate = 9600;
                port.PortName = "COM6";

                port.Open();

                try
                {
                    port.Write("Hello from PC\n");
                    Debug.Log(port.ReadLine());
                }
                catch (System.Exception ex)
                {
                    status.text = "Error communicating over Bluetooth serial port";
                    Debug.Log(ex);
                    return;
                }

                status.text = "Connected";
            }
            catch (System.Exception ex)
            {
                status.text = "Error opening Bluetooth serial port";
                Debug.Log(ex);
                return;
            }
        }
    }

    void Update()
    {
        if (port != null)
        {
            string receivedData = port.ReadExisting();
            if (receivedData.Length > 0)
            {
                TextBehavior.AddNewData(receivedData);
            }
        }
    }

}
